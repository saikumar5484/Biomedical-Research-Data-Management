console.log("JavaScript is working!");
